document.getElementById('translateBtn').addEventListener('click', async () => {
    const text = document.getElementById('inputText').value.trim();
    const lang = document.getElementById('languageSelect').value;

    if (!text) {
        alert('Please enter some text.');
        return;
    }

    // Call your translation API
    try {
        const response = await fetch('/api/translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text, target_language: lang })
        });
        if (!response.ok) throw new Error('Translation failed');
        const data = await response.json();
        const translatedText = data.translated_text || '[No translation returned]';

        // Chat Bot Functionality (optional: you can move this to chatbot.js if you want)
        const chatContent = document.getElementById('chatContent');
        chatContent.innerHTML += `<p>User: ${text}</p><p>Bot: Translated to ${lang}: ${translatedText}</p>`;
        chatContent.scrollTop = chatContent.scrollHeight;
    } catch (error) {
        alert('Error: ' + error.message);
    }

    document.getElementById('inputText').value = '';
});

document.getElementById('sendBtn').addEventListener('click', () => {
    const chatInput = document.getElementById('chatInput').value.trim();
    const chatContent = document.getElementById('chatContent');

    if (chatInput) {
        chatContent.innerHTML += `<p>User: ${chatInput}</p><p>Bot: Thanks for your message! How can I help with African culture today?</p>`;
        chatContent.scrollTop = chatContent.scrollHeight;
        document.getElementById('chatInput').value = '';
    }
});

// Hero background slideshow
(function() {
    const images = [
        'images/WhatsApp Image 2025-06-23 at 16.41.17_525e2d32.jpg',
        'images/WhatsApp Image 2025-06-23 at 16.41.18_f3a3c7df.jpg',
        'images/WhatsApp Image 2025-06-23 at 16.41.18_0b690c00.jpg'
    ];
    let idx = 0;
    const bg = document.getElementById('heroBgSlideshow');
    function setBg() {
        if (bg) bg.style.backgroundImage = `url('${images[idx]}')`;
    }
    setBg();
    setInterval(() => {
        idx = (idx + 1) % images.length;
        setBg();
    }, 4000);
})();